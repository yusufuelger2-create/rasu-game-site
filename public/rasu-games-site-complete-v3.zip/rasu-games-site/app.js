const cursorGlow = document.querySelector('.cursor-glow');
window.addEventListener('pointermove', (e) => {
  if (cursorGlow) {
    cursorGlow.style.left = `${e.clientX}px`;
    cursorGlow.style.top = `${e.clientY}px`;
  }
});

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.reveal').forEach((el, i) => {
  el.style.transitionDelay = `${Math.min(i * 50, 250)}ms`;
  observer.observe(el);
});

const menu = document.querySelector('.menu-toggle');
const nav = document.querySelector('.desktop-nav');
menu?.addEventListener('click', () => {
  const open = menu.getAttribute('aria-expanded') === 'true';
  menu.setAttribute('aria-expanded', String(!open));
  nav?.classList.toggle('mobile-open', !open);
});

document.querySelectorAll('.desktop-nav a').forEach((link) => {
  link.addEventListener('click', () => {
    menu?.setAttribute('aria-expanded', 'false');
    nav?.classList.remove('mobile-open');
  });
});

// Featured game slider: Pro League Soccer first, then Pro Kick Soccer.
const slides = [...document.querySelectorAll('.hero-slide')];
const dots = [...document.querySelectorAll('.hero-dot')];
let currentSlide = 0;
let sliderTimer;

function videoUrl(id) {
  return `https://www.youtube-nocookie.com/embed/${id}?autoplay=1&mute=1&loop=1&playlist=${id}&controls=0&playsinline=1&rel=0&modestbranding=1&iv_load_policy=3&disablekb=1`;
}

function loadVideo(slide) {
  const iframe = slide.querySelector('iframe');
  if (!iframe || iframe.src) return;
  iframe.src = videoUrl(slide.dataset.video);
}

function unloadVideo(slide) {
  const iframe = slide.querySelector('iframe');
  if (iframe) iframe.removeAttribute('src');
}

function showSlide(index) {
  if (!slides.length) return;
  currentSlide = (index + slides.length) % slides.length;

  slides.forEach((slide, i) => {
    slide.classList.toggle('active', i === currentSlide);
    if (i !== currentSlide) unloadVideo(slide);
  });

  dots.forEach((dot, i) => dot.classList.toggle('active', i === currentSlide));
  loadVideo(slides[currentSlide]);

  clearTimeout(sliderTimer);
  sliderTimer = setTimeout(() => showSlide(currentSlide + 1), 10000);
}

dots.forEach((dot, index) => {
  dot.addEventListener('click', () => showSlide(index));
});

showSlide(0);

// Pause automatic switching while the pointer is over the controls.
const heroControls = document.querySelector('.hero-slide-controls');
heroControls?.addEventListener('mouseenter', () => clearTimeout(sliderTimer));
heroControls?.addEventListener('mouseleave', () => {
  clearTimeout(sliderTimer);
  sliderTimer = setTimeout(() => showSlide(currentSlide + 1), 10000);
});

// Games section picker: switch the logo, artwork and store links without leaving the page.
const gamePickerButtons = [...document.querySelectorAll('.game-picker-btn')];
const gameShowcaseCards = [...document.querySelectorAll('.game-showcase-card')];
const gameNumber = document.querySelector('.game-number');
const showcaseTitle = document.querySelector('.showcase h2');
const showcaseCopy = document.querySelector('.showcase-copy>p:not(.eyebrow)');
const showcaseTags = document.querySelector('.tag-row');

const showcaseData = {
  pls: {
    number: '01',
    title: 'TWO GAMES.<br /><em>ONE STUDIO.</em>',
    copy: 'Pro League Soccer puts you in control with deep football simulation, squad building and customization across Android and iOS.',
    tags: ['PRO LEAGUE SOCCER', 'ANDROID + IOS', 'FOOTBALL SIMULATION']
  },
  pks: {
    number: '02',
    title: 'FAST FOOTBALL.<br /><em>PURE ACTION.</em>',
    copy: 'Pro Kick Soccer is built for quick matches, sharp moments and accessible football action across Android and iOS.',
    tags: ['PRO KICK SOCCER', 'ANDROID + IOS', 'FAST MATCHES']
  }
};

function chooseGame(game) {
  const data = showcaseData[game];
  if (!data) return;
  gamePickerButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.gameChoice === game));
  gameShowcaseCards.forEach(card => {
    const selected = card.dataset.showcaseGame === game;
    card.classList.toggle('hidden', !selected);
    if (selected) { card.style.animation = 'none'; void card.offsetWidth; card.style.animation = ''; }
  });
  if (gameNumber) gameNumber.textContent = data.number;
}

gamePickerButtons.forEach(btn => btn.addEventListener('click', () => chooseGame(btn.dataset.gameChoice)));
chooseGame('pls');

// Contact form: reveal bug-specific fields and provide a safe local/demo submission flow.
const contactTopic = document.querySelector('#contactTopic');
const bugFields = document.querySelector('#bugFields');
const bugAttachment = document.querySelector('#bugAttachment');
const contactForm = document.querySelector('#contactForm');
const formStatus = document.querySelector('#formStatus');

function toggleBugFields() {
  const isBug = contactTopic?.value === 'bug-report';
  if (bugFields) bugFields.hidden = !isBug;
  if (!isBug && bugAttachment) bugAttachment.value = '';
}
contactTopic?.addEventListener('change', toggleBugFields);
toggleBugFields();

contactForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!contactForm.checkValidity()) {
    contactForm.reportValidity();
    return;
  }

  if (bugAttachment?.files?.[0] && bugAttachment.files[0].size > 10 * 1024 * 1024) {
    if (formStatus) { formStatus.textContent = 'The screenshot must be 10 MB or smaller.'; formStatus.classList.add('error'); }
    return;
  }

  // The form UI is ready for a real mail provider. Keep the demo honest instead of pretending
  // an email was sent when no provider credentials have been configured.
  if (formStatus) {
    formStatus.classList.remove('error');
    formStatus.textContent = 'Form validated. Connect your preferred email/form provider to receive submissions.';
  }
});

// Footballer Name Generator
(() => {
  const countryEl = document.querySelector('#nameCountry');
  const countEl = document.querySelector('#nameCount');
  const countValueEl = document.querySelector('#nameCountValue');
  const ratioEl = document.querySelector('#newNameRatio');
  const ratioValueEl = document.querySelector('#newNameRatioValue');
  const avoidRepeatsEl = document.querySelector('#avoidSessionRepeats');
  const generateEl = document.querySelector('#generateNames');
  const copyEl = document.querySelector('#copyNames');
  const listEl = document.querySelector('#nameList');
  const generatedCountEl = document.querySelector('#generatedCount');

  if (!countryEl || !countEl || !ratioEl || !generateEl || !listEl) return;

  const NAME_SESSION_KEY = 'rasu_generated_footballer_names_v3';
  const SURNAME_SESSION_KEY = 'rasu_generated_footballer_surnames_v2';
  let nameData = null;
  let generatedNames = [];

  const normalizeName = (value) => String(value || '')
    .toLocaleLowerCase('en-US')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '');

  const randomItem = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const capitalize = (value) => value ? value.charAt(0).toUpperCase() + value.slice(1) : value;

  function getSessionNames() {
    try { return JSON.parse(sessionStorage.getItem(NAME_SESSION_KEY) || '[]'); }
    catch { return []; }
  }

  function saveSessionNames(names) {
    try { sessionStorage.setItem(NAME_SESSION_KEY, JSON.stringify(names)); } catch {}
  }

  // Stored per country so a common surname in one country does not block it in another.
  function getSessionSurnames() {
    try {
      const value = JSON.parse(sessionStorage.getItem(SURNAME_SESSION_KEY) || '{}');
      return value && typeof value === 'object' ? value : {};
    } catch { return {}; }
  }

  function saveSessionSurnames(value) {
    try { sessionStorage.setItem(SURNAME_SESSION_KEY, JSON.stringify(value)); } catch {}
  }

  function updateControls() {
    if (countValueEl) countValueEl.textContent = countEl.value;
    if (ratioValueEl) ratioValueEl.textContent = `${ratioEl.value}%`;
  }
  countEl.addEventListener('input', updateControls);
  ratioEl.addEventListener('input', updateControls);
  updateControls();

  function validSynthetic(value) {
    if (!value || value.length < 4 || value.length > 15) return false;
    if (/[^a-zA-ZÀ-ÿ]/.test(value)) return false;
    if (/(.)\1\1/i.test(value.toLowerCase())) return false;
    if (/[bcdfghjklmnpqrstvwxyz]{4}/i.test(value)) return false;
    if (/[aeiouy]{4}/i.test(value)) return false;
    return true;
  }

  function syntheticFirstName(country) {
    const used = new Set(country.firstNames.map(normalizeName));
    for (let i = 0; i < 120; i += 1) {
      const syllable = randomItem(country.syllables || []);
      const ending = randomItem(country.endings || []);
      const candidate = capitalize(`${syllable}${ending}`);
      const key = normalizeName(candidate);
      if (validSynthetic(candidate) && !used.has(key)) return candidate;
    }
    return randomItem(country.firstNames);
  }

  function realFirstName(country) {
    return randomItem(country.firstNames);
  }

  function pickUnusedSurname(country, blockedSurnames) {
    const pool = country.lastNames || [];
    if (!pool.length) return null;

    // First pass: completely unused surname.
    const available = pool.filter((surname) => !blockedSurnames.has(normalizeName(surname)));
    if (available.length) return randomItem(available);

    // This fallback is only reachable when the surname pool is exhausted.
    // With the current 80+ surnames/country and a max squad size of 20, it should
    // normally never happen during a session.
    return null;
  }

  function makePlayer(country, makeNew, blockedSurnames) {
    const first = makeNew ? syntheticFirstName(country) : realFirstName(country);
    const last = pickUnusedSurname(country, blockedSurnames);
    if (!last) return null;
    return { name: `${first} ${last}`, surname: last, type: makeNew ? 'NEW' : 'REAL' };
  }

  async function loadNames() {
    if (nameData) return nameData;
    try {
      const response = await fetch('./names.json', { cache: 'no-store' });
      if (!response.ok) throw new Error(`names.json returned ${response.status}`);
      nameData = await response.json();
      if (!nameData?.countries) throw new Error('Invalid names.json structure');
      return nameData;
    } catch (error) {
      console.error('Footballer Name Generator: names.json could not be loaded.', error);
      listEl.innerHTML = '<div class="name-empty">Could not load names.json. Run the site through a local web server (for example: python -m http.server).</div>';
      return null;
    }
  }

  function render(names) {
    generatedNames = names;
    if (generatedCountEl) generatedCountEl.textContent = `${names.length} ${names.length === 1 ? 'NAME' : 'NAMES'}`;
    if (copyEl) copyEl.disabled = names.length === 0;
    if (!names.length) {
      listEl.innerHTML = '<div class="name-empty">No unique surnames are available with the current session settings. Try another country or turn off session repeat protection.</div>';
      return;
    }
    listEl.innerHTML = names.map((entry, index) => `
      <div class="generated-name" style="animation-delay:${Math.min(index * 25, 250)}ms">
        <span class="generated-name-number">${String(index + 1).padStart(2, '0')}</span>
        <span class="generated-name-text">${escapeHtml(entry.name)}</span>
        <span class="name-type">${entry.type}</span>
      </div>`).join('');
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, (char) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' })[char]);
  }

  async function generate() {
    generateEl.disabled = true;
    const data = await loadNames();
    if (!data) { generateEl.disabled = false; return; }

    const countryKey = countryEl.value;
    const country = data.countries[countryKey];
    if (!country) { generateEl.disabled = false; return; }

    const count = Math.max(1, Math.min(20, Number(countEl.value) || 1));
    const newRatio = Math.max(0, Math.min(100, Number(ratioEl.value) || 0));
    const avoidSessionRepeats = Boolean(avoidRepeatsEl?.checked);

    const sessionNames = new Set(avoidSessionRepeats ? getSessionNames() : []);
    const sessionSurnameMap = getSessionSurnames();
    const countrySessionSurnames = new Set(
      avoidSessionRepeats ? (sessionSurnameMap[countryKey] || []).map(normalizeName) : []
    );

    // Surname uniqueness is enforced even when session protection is OFF: no surname
    // repeats inside the current generated squad.
    const batchSurnames = new Set();
    const batchNames = new Set();
    const blockedSurnames = new Set(countrySessionSurnames);
    const result = [];

    for (let attempts = 0; attempts < count * 250 && result.length < count; attempts += 1) {
      const makeNew = Math.random() * 100 < newRatio;
      const player = makePlayer(country, makeNew, new Set([...blockedSurnames, ...batchSurnames]));
      if (!player) break;

      const nameKey = normalizeName(player.name);
      const surnameKey = normalizeName(player.surname);
      if (!nameKey || !surnameKey || batchNames.has(nameKey) || sessionNames.has(nameKey)) continue;
      if (batchSurnames.has(surnameKey) || countrySessionSurnames.has(surnameKey)) continue;

      batchNames.add(nameKey);
      batchSurnames.add(surnameKey);
      result.push(player);
    }

    if (avoidSessionRepeats) {
      saveSessionNames([...sessionNames, ...result.map((entry) => normalizeName(entry.name))]);
      const existing = new Set(sessionSurnameMap[countryKey] || []);
      result.forEach((entry) => existing.add(normalizeName(entry.surname)));
      sessionSurnameMap[countryKey] = [...existing];
      saveSessionSurnames(sessionSurnameMap);
    }

    render(result);
    generateEl.disabled = false;
  }

  async function copyAll() {
    if (!generatedNames.length) return;
    const text = generatedNames.map((entry) => entry.name).join('\n');
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      textarea.remove();
    }
    const original = copyEl.innerHTML;
    copyEl.innerHTML = 'COPIED ✓';
    setTimeout(() => { copyEl.innerHTML = original; }, 1400);
  }

  generateEl.addEventListener('click', generate);
  copyEl?.addEventListener('click', copyAll);

  // Transfermarkt real-player alternative names
  const squadSourceUrlEl = document.querySelector('#squadSourceUrl');
  const loadSquadEl = document.querySelector('#loadSquad');
  const squadStatusEl = document.querySelector('#squadStatus');
  const realPlayerListEl = document.querySelector('#realPlayerList');
  const alternativeCountryLabelEl = document.querySelector('#alternativeCountryLabel');
  let realPlayers = [];
  const alternativeNames = new Map();
  const usedAlternativeNames = new Set();

  const fallbackSquad = [
    'Ederson','Tarık Çetin','Mert Günok','Engin Can Biterge','Jayden Oosterwolde',
    'Milan Škriniar','Yiğit Efe Demir','Çağlar Söyüncü','Kamil Efe Üregen','Archie Brown',
    'Levent Mercan','Mert Müldür','Nélson Semedo','İsmail Yüksek','Edson Álvarez',
    "N'Golo Kanté",'Mattéo Guendouzi','Fred','Abdou Aziz Fall','Marco Asensio',
    'Talisca','Mert Hakan Yandaş','Kerem Aktürkoğlu','Anthony Musaba','Dorgeles Nene',
    'Oğuz Aydın','Emre Mor','Sidiki Chérif'
  ];

  const countryLabels = {
    germany: 'Germany', england: 'England', france: 'France',
    spain: 'Spain', brazil: 'Brazil', turkey: 'Turkey'
  };

  function updateAlternativeCountryLabel() {
    if (alternativeCountryLabelEl) alternativeCountryLabelEl.textContent = countryLabels[countryEl.value] || countryEl.value;
  }
  countryEl.addEventListener('change', updateAlternativeCountryLabel);
  updateAlternativeCountryLabel();

  function extractPlayerNames(text) {
    const source = String(text || '');
    const names = [];
    const seen = new Set();

    // Transfermarkt's readable/markdown representation commonly contains:
    // "Image: Player Name Player Name". The backreference prevents nationality
    // labels and unrelated image text from being mistaken for players.
    const repeatedImagePattern = /Image:\s+([^\n|]+?)\s+\1(?=\s|$|\|)/giu;
    let match;
    while ((match = repeatedImagePattern.exec(source))) {
      const name = match[1].replace(/\s+/g, ' ').trim();
      const key = normalizeName(name);
      if (name.length >= 3 && name.length <= 60 && !seen.has(key)) {
        seen.add(key);
        names.push(name);
      }
    }

    // HTML fallback: player profile links are more reliable when direct HTML is available.
    if (names.length < 3 && /<html|<table|<a\b/i.test(source)) {
      try {
        const doc = new DOMParser().parseFromString(source, 'text/html');
        doc.querySelectorAll('a[href*="/profil/spieler/"]').forEach((link) => {
          const name = (link.textContent || '').replace(/\s+/g, ' ').trim();
          const key = normalizeName(name);
          if (name.length >= 3 && name.length <= 60 && !seen.has(key)) {
            seen.add(key);
            names.push(name);
          }
        });
      } catch {}
    }

    return names;
  }

  async function fetchSquadText(url) {
    const cleanUrl = url.trim();
    if (!/^https:\/\/www\.transfermarkt\.com\.tr\//i.test(cleanUrl)) {
      throw new Error('Please use a Transfermarkt.com.tr squad URL.');
    }

    const encoded = encodeURIComponent(cleanUrl);
    const readerUrl = `https://r.jina.ai/http://r.jina.ai/${encoded}`;
    const urls = [
      `https://r.jina.ai/${cleanUrl}`,
      `https://api.allorigins.win/raw?url=${encoded}`,
      cleanUrl
    ];

    let lastError = null;
    for (const endpoint of urls) {
      try {
        const response = await fetch(endpoint, { headers: { 'Accept': 'text/plain,text/html;q=0.9,*/*;q=0.8' } });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const text = await response.text();
        if (text.length > 500) return text;
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error('Could not read the squad page.');
  }

  function renderRealPlayers() {
    if (!realPlayerListEl) return;
    if (!realPlayers.length) {
      realPlayerListEl.innerHTML = '<div class="name-empty">No player names were found on this page.</div>';
      return;
    }

    realPlayerListEl.innerHTML = realPlayers.map((player, index) => {
      const key = normalizeName(player);
      const alternative = alternativeNames.get(key) || '—';
      return `
        <div class="real-player-row" data-player-key="${escapeHtml(key)}">
          <span class="real-player-index">${String(index + 1).padStart(2, '0')}</span>
          <span class="real-player-original" title="${escapeHtml(player)}">${escapeHtml(player)}</span>
          <span class="real-player-arrow">→</span>
          <span class="real-player-alternative" title="${escapeHtml(alternative)}">${escapeHtml(alternative)}</span>
          <button class="real-player-die" type="button" data-player-index="${index}" aria-label="Generate alternative name for ${escapeHtml(player)}" title="Generate alternative name">⚄</button>
        </div>`;
    }).join('');
  }

  function generateAlternative(player) {
    const data = nameData;
    const country = data?.countries?.[countryEl.value];
    if (!country) return null;

    const blockedSurnames = new Set();
    const sessionSurnameMap = getSessionSurnames();
    if (avoidRepeatsEl?.checked) {
      (sessionSurnameMap[countryEl.value] || []).forEach((value) => blockedSurnames.add(normalizeName(value)));
    }

    realPlayers.forEach((name) => {
      const existing = alternativeNames.get(normalizeName(name));
      if (existing) {
        const surname = existing.split(/\s+/).slice(1).join(' ');
        blockedSurnames.add(normalizeName(surname));
      }
    });

    for (let attempt = 0; attempt < 300; attempt += 1) {
      const candidate = makePlayer(country, true, blockedSurnames);
      if (!candidate) continue;
      const key = normalizeName(candidate.name);
      const originalKey = normalizeName(player);
      if (key === originalKey) continue;
      if (usedAlternativeNames.has(key)) continue;
      if (realPlayers.some((name) => normalizeName(name) === key)) continue;
      usedAlternativeNames.add(key);
      return candidate.name;
    }
    return null;
  }

  async function rollAlternative(index) {
    const player = realPlayers[index];
    if (!player) return;
    const button = realPlayerListEl?.querySelector(`[data-player-index="${index}"]`);
    if (button) button.disabled = true;

    try {
      await loadNames();
      const alternative = generateAlternative(player);
      if (!alternative) throw new Error('No unused alternative name is available.');
      alternativeNames.set(normalizeName(player), alternative);
      renderRealPlayers();
    } catch (error) {
      if (squadStatusEl) squadStatusEl.textContent = error.message || 'Could not generate an alternative name.';
    } finally {
      const nextButton = realPlayerListEl?.querySelector(`[data-player-index="${index}"]`);
      if (nextButton) nextButton.disabled = false;
    }
  }

  realPlayerListEl?.addEventListener('click', (event) => {
    const button = event.target.closest('.real-player-die');
    if (!button) return;
    rollAlternative(Number(button.dataset.playerIndex));
  });

  async function loadSquad() {
    if (!loadSquadEl || !realPlayerListEl) return;
    loadSquadEl.disabled = true;
    loadSquadEl.innerHTML = 'LOADING...';
    if (squadStatusEl) squadStatusEl.textContent = 'Reading Transfermarkt squad...';
    realPlayerListEl.innerHTML = '<div class="name-empty">Loading squad...</div>';
    alternativeNames.clear();
    usedAlternativeNames.clear();

    try {
      const url = squadSourceUrlEl?.value || '';
      const text = await fetchSquadText(url);
      let names = extractPlayerNames(text);

      // If Transfermarkt blocks the browser-side reader, keep the tool usable with
      // the currently known Fenerbahçe squad rather than showing an empty widget.
      if (names.length < 3 && /fenerbahce|fenerbahçe/i.test(url)) names = [...fallbackSquad];
      if (names.length < 1) throw new Error('No player names could be extracted from this Transfermarkt page.');

      realPlayers = names;
      if (squadStatusEl) squadStatusEl.textContent = `${names.length} PLAYERS LOADED · Click ⚄ to generate an alternative.`;
      renderRealPlayers();
    } catch (error) {
      realPlayers = [];
      realPlayerListEl.innerHTML = `<div class="real-player-error">${escapeHtml(error.message || 'Could not load the squad.')}<br /><small>If Transfermarkt blocks the reader, try again later or use the Fenerbahçe URL supplied by default.</small></div>`;
      if (squadStatusEl) squadStatusEl.textContent = 'SQUAD LOAD FAILED';
    } finally {
      loadSquadEl.disabled = false;
      loadSquadEl.innerHTML = 'LOAD SQUAD <span>↗</span>';
    }
  }

  loadSquadEl?.addEventListener('click', loadSquad);
  squadSourceUrlEl?.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') loadSquad();
  });

  // Load the default Fenerbahçe squad once the generator data is ready.
  loadSquad();
})();
